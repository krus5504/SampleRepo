package Student.Controllar;

import java.io.IOException;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.ResponseBody;


import Student.User;
import Student.UserDao.UserDao;

@Controller

public class Controller1 {
	@Autowired
	UserDao userDao;
	
	@GetMapping("/fName")
	public String frentName() {
		String name="Welcome to server ";
		return "home";
	}
	@GetMapping("/singUp")
	public String singUp() {
		return "SingUp";
	}
	
	@GetMapping("/login")
	public String login() {
		return "loginPage";
	}
	@PostMapping("/success")
	public String Success( User user) {
		String userName=user.getUserName();
		String password=user.getPassword();
		
		List<User> findAll = userDao.findAll();
		for (User user2 : findAll) {
			if (user2.getUserName().equals(userName)&&(user2.getPassword().equals(password))) {
				return "success";
			}
			
		}
		
		return "failuar";
	}
	
	@PostMapping("/SaveData")
	public String saveUser( User user) {
		String userName=user.getUserName();
		String password=user.getPassword();
		User u1= new User();
		u1.setUserName(userName);
		u1.setPassword(password);
		
		userDao.save(u1);
		return "saveUser";
	}
	
	@GetMapping("/tea")
	public String teacherLoginPage() {
		String name="Welcome to teacherLoginPage";
		return "home";
		
	}
	@GetMapping("/studentLogin")
	
	public String studentLoginPage() throws IOException {
		String name="Welcome to studentLoginPage ";
		return "StudentLoginForm";
		
	}
	@GetMapping("/addNewStudent")
	@ResponseBody
	public String studentSignUpPage() {
		String name="Welcome to studentSignUpPage ";
		return name;
		
	}
}
